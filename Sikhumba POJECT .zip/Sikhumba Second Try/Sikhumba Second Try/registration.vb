﻿


Imports System.Data.OleDb
Imports System.Diagnostics.Eventing.Reader ' Use OleDb for Access Database

Public Class registration
    Private con As OleDbConnection ' Define connection object at class level

    Private Sub registration_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cboGender.Items.Add("Male")
        cboGender.Items.Add("Female")
    End Sub

    Private Sub btnRegisterAcc_Click(sender As Object, e As EventArgs) Handles btnRegisterAcc.Click
        If IsEmpty(txtName.Text) Then
            MsgBox("Name cannot be empty")
            txtName.Focus()
            Exit Sub
        End If

        If IsEmpty(txtSurname.Text) Then
            MsgBox("Surname cannot be empty")
            txtSurname.Focus()
            Exit Sub
        End If

        If IsEmpty(txtCellNumber.Text) Then
            MsgBox("Cell Number cannot be empty")
            txtCellNumber.Focus()
            Exit Sub
        End If

        If Not isNumber(txtCellNumber.Text) Then
            MsgBox("Cell Number should only contain numbers")
            txtCellNumber.Focus()
            Exit Sub
        End If

        If txtCellNumber.Text.Length <> 10 Then
            MsgBox("Cell Number should be 10 digits")
            txtCellNumber.Focus()
            Exit Sub
        End If

        If Not txtCellNumber.Text.StartsWith("0") Then
            MsgBox("Cell Number must begin with 0")
            txtCellNumber.Focus()
            Exit Sub
        End If

        If IsEmpty(txtEmail.Text) Then
            MsgBox("Email cannot be empty")
            txtEmail.Focus()
            Exit Sub
        End If

        If IsEmpty(txtPassword.Text) Then
            MsgBox("Password cannot be empty")
            txtPassword.Focus()
            Exit Sub
        End If

        If Not isAlpha(txtName.Text) Then
            MsgBox("Name should contain alphabetic letters only")
            txtName.Focus()
            Exit Sub
        End If

        If Not isAlpha(txtSurname.Text) Then
            MsgBox("Surname should contain alphabetic letters only")
            txtSurname.Focus()
            Exit Sub
        End If

        If getConnection() Then
            If registerStudent(txtName.Text, txtSurname.Text, txtCellNumber.Text, cboGender.Text, txtAddress.Text, txtEmail.Text, txtPassword.Text) Then
                MsgBox("Registered successfully")
                Me.Hide()
                Form1.Show()
            Else
                MsgBox("Registration failed")
            End If
        Else
            MsgBox("Failed to connect to the database")
        End If
    End Sub

    Function getConnection() As Boolean
        Try
            con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Student\Documents\Sikhumba1.mdb ")
            con.Open() ' Open the connection here
            Return True
        Catch ex As Exception
            MsgBox("Error: " & ex.Message) ' Show error message for debugging
            Return False
        End Try
    End Function

    Function registerStudent(Name As String, Surname As String, CellNumber As String, Gender As String, Address As String, Email As String, Password As String) As Boolean
        Dim returnValue As Boolean = False
        Dim sql As String = "INSERT INTO Customers ([Name], [Surname], [CellNumber], [Gender], [Address], [Email], [Password]) VALUES (@Name, @Surname, @CellNumber, @Gender, @Address, @Email, @Password)"

        Try
            Using cmd As New OleDbCommand(sql, con)
                cmd.Parameters.AddWithValue("@Name", Name)
                cmd.Parameters.AddWithValue("@Surname", Surname)
                cmd.Parameters.AddWithValue("@CellNumber", CellNumber)
                cmd.Parameters.AddWithValue("@Gender", Gender)
                cmd.Parameters.AddWithValue("@Address", Address)
                cmd.Parameters.AddWithValue("@Email", Email)
                cmd.Parameters.AddWithValue("@Passwword", Password)

                cmd.ExecuteNonQuery()
                returnValue = True
            End Using
        Catch ex As Exception
            MsgBox("Error: " & ex.Message) ' Show error message for debugging
            returnValue = False
        End Try
        Return returnValue
    End Function

    Private Function IsEmpty(textbox As String) As Boolean
        Return String.IsNullOrWhiteSpace(textbox)
    End Function

    Private Function isNumber(textbox As String) As Boolean
        Return IsNumeric(textbox)
    End Function

    Private Function isAlpha(textbox As String) As Boolean
        For i = 0 To textbox.Length - 1
            Dim ch As Char = textbox(i)
            If Not Char.IsLetter(ch) AndAlso ch <> " "c Then
                Return False
            End If
        Next
        Return True
    End Function

    Private Sub registration_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Dim var = MsgBox("Are you sure you want to close the app?", vbYesNo + vbQuestion, "Close App?")
        If var = vbYes Then
            Me.Dispose()
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        Form1.Show()
    End Sub
End Class