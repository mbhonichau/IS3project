﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Home
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Home))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txtWelcome = New System.Windows.Forms.TextBox()
        Me.btnLogout = New System.Windows.Forms.Button()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.radDelivery = New System.Windows.Forms.RadioButton()
        Me.radCollection = New System.Windows.Forms.RadioButton()
        Me.txtPrice = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkSparkPlugs = New System.Windows.Forms.CheckBox()
        Me.chkMirrors = New System.Windows.Forms.CheckBox()
        Me.chkOilfilters = New System.Windows.Forms.CheckBox()
        Me.chkTires = New System.Windows.Forms.CheckBox()
        Me.chkWindsheilds = New System.Windows.Forms.CheckBox()
        Me.chkBreak = New System.Windows.Forms.CheckBox()
        Me.chkBattery = New System.Windows.Forms.CheckBox()
        Me.chkRims = New System.Windows.Forms.CheckBox()
        Me.chkGearBox = New System.Windows.Forms.CheckBox()
        Me.chkBumper = New System.Windows.Forms.CheckBox()
        Me.cboCarType = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtCustomerName = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(29, 18)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(129, 127)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 35
        Me.PictureBox1.TabStop = False
        '
        'txtWelcome
        '
        Me.txtWelcome.Location = New System.Drawing.Point(320, 18)
        Me.txtWelcome.Multiline = True
        Me.txtWelcome.Name = "txtWelcome"
        Me.txtWelcome.Size = New System.Drawing.Size(157, 24)
        Me.txtWelcome.TabIndex = 34
        '
        'btnLogout
        '
        Me.btnLogout.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogout.Location = New System.Drawing.Point(680, 386)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Size = New System.Drawing.Size(92, 47)
        Me.btnLogout.TabIndex = 33
        Me.btnLogout.Text = "Logout"
        Me.btnLogout.UseVisualStyleBackColor = True
        '
        'btnCalc
        '
        Me.btnCalc.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalc.Location = New System.Drawing.Point(554, 386)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(92, 47)
        Me.btnCalc.TabIndex = 32
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.radDelivery)
        Me.GroupBox2.Controls.Add(Me.radCollection)
        Me.GroupBox2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(524, 211)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(228, 129)
        Me.GroupBox2.TabIndex = 31
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Delivery Method"
        '
        'radDelivery
        '
        Me.radDelivery.AutoSize = True
        Me.radDelivery.Location = New System.Drawing.Point(47, 77)
        Me.radDelivery.Name = "radDelivery"
        Me.radDelivery.Size = New System.Drawing.Size(75, 21)
        Me.radDelivery.TabIndex = 1
        Me.radDelivery.TabStop = True
        Me.radDelivery.Text = "Delivery"
        Me.radDelivery.UseVisualStyleBackColor = True
        '
        'radCollection
        '
        Me.radCollection.AutoSize = True
        Me.radCollection.Location = New System.Drawing.Point(49, 38)
        Me.radCollection.Name = "radCollection"
        Me.radCollection.Size = New System.Drawing.Size(85, 21)
        Me.radCollection.TabIndex = 0
        Me.radCollection.TabStop = True
        Me.radCollection.Text = "Collection"
        Me.radCollection.UseVisualStyleBackColor = True
        '
        'txtPrice
        '
        Me.txtPrice.Location = New System.Drawing.Point(320, 401)
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.Size = New System.Drawing.Size(141, 20)
        Me.txtPrice.TabIndex = 30
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(232, 401)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 20)
        Me.Label4.TabIndex = 29
        Me.Label4.Text = "Price"
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(321, 174)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(141, 20)
        Me.txtAddress.TabIndex = 28
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(233, 174)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 20)
        Me.Label3.TabIndex = 27
        Me.Label3.Text = "Address"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkSparkPlugs)
        Me.GroupBox1.Controls.Add(Me.chkMirrors)
        Me.GroupBox1.Controls.Add(Me.chkOilfilters)
        Me.GroupBox1.Controls.Add(Me.chkTires)
        Me.GroupBox1.Controls.Add(Me.chkWindsheilds)
        Me.GroupBox1.Controls.Add(Me.chkBreak)
        Me.GroupBox1.Controls.Add(Me.chkBattery)
        Me.GroupBox1.Controls.Add(Me.chkRims)
        Me.GroupBox1.Controls.Add(Me.chkGearBox)
        Me.GroupBox1.Controls.Add(Me.chkBumper)
        Me.GroupBox1.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(119, 200)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(358, 177)
        Me.GroupBox1.TabIndex = 26
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Car Parts "
        '
        'chkSparkPlugs
        '
        Me.chkSparkPlugs.AutoSize = True
        Me.chkSparkPlugs.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkSparkPlugs.Location = New System.Drawing.Point(202, 147)
        Me.chkSparkPlugs.Name = "chkSparkPlugs"
        Me.chkSparkPlugs.Size = New System.Drawing.Size(98, 21)
        Me.chkSparkPlugs.TabIndex = 9
        Me.chkSparkPlugs.Text = "Spark Plugs"
        Me.chkSparkPlugs.UseVisualStyleBackColor = True
        '
        'chkMirrors
        '
        Me.chkMirrors.AutoSize = True
        Me.chkMirrors.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkMirrors.Location = New System.Drawing.Point(52, 147)
        Me.chkMirrors.Name = "chkMirrors"
        Me.chkMirrors.Size = New System.Drawing.Size(71, 21)
        Me.chkMirrors.TabIndex = 8
        Me.chkMirrors.Text = "Mirrors"
        Me.chkMirrors.UseVisualStyleBackColor = True
        '
        'chkOilfilters
        '
        Me.chkOilfilters.AutoSize = True
        Me.chkOilfilters.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkOilfilters.Location = New System.Drawing.Point(202, 120)
        Me.chkOilfilters.Name = "chkOilfilters"
        Me.chkOilfilters.Size = New System.Drawing.Size(80, 21)
        Me.chkOilfilters.TabIndex = 7
        Me.chkOilfilters.Text = "Oil filters"
        Me.chkOilfilters.UseVisualStyleBackColor = True
        '
        'chkTires
        '
        Me.chkTires.AutoSize = True
        Me.chkTires.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkTires.Location = New System.Drawing.Point(202, 93)
        Me.chkTires.Name = "chkTires"
        Me.chkTires.Size = New System.Drawing.Size(74, 21)
        Me.chkTires.TabIndex = 6
        Me.chkTires.Text = "Tires X4"
        Me.chkTires.UseVisualStyleBackColor = True
        '
        'chkWindsheilds
        '
        Me.chkWindsheilds.AutoSize = True
        Me.chkWindsheilds.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkWindsheilds.Location = New System.Drawing.Point(202, 66)
        Me.chkWindsheilds.Name = "chkWindsheilds"
        Me.chkWindsheilds.Size = New System.Drawing.Size(100, 21)
        Me.chkWindsheilds.TabIndex = 5
        Me.chkWindsheilds.Text = "Windsheilds"
        Me.chkWindsheilds.UseVisualStyleBackColor = True
        '
        'chkBreak
        '
        Me.chkBreak.AutoSize = True
        Me.chkBreak.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkBreak.Location = New System.Drawing.Point(202, 39)
        Me.chkBreak.Name = "chkBreak"
        Me.chkBreak.Size = New System.Drawing.Size(94, 21)
        Me.chkBreak.TabIndex = 4
        Me.chkBreak.Text = "Brake Pads"
        Me.chkBreak.UseVisualStyleBackColor = True
        '
        'chkBattery
        '
        Me.chkBattery.AutoSize = True
        Me.chkBattery.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkBattery.Location = New System.Drawing.Point(52, 120)
        Me.chkBattery.Name = "chkBattery"
        Me.chkBattery.Size = New System.Drawing.Size(72, 21)
        Me.chkBattery.TabIndex = 3
        Me.chkBattery.Text = "Battery"
        Me.chkBattery.UseVisualStyleBackColor = True
        '
        'chkRims
        '
        Me.chkRims.AutoSize = True
        Me.chkRims.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkRims.Location = New System.Drawing.Point(52, 93)
        Me.chkRims.Name = "chkRims"
        Me.chkRims.Size = New System.Drawing.Size(56, 21)
        Me.chkRims.TabIndex = 2
        Me.chkRims.Text = "Rims"
        Me.chkRims.UseVisualStyleBackColor = True
        '
        'chkGearBox
        '
        Me.chkGearBox.AutoSize = True
        Me.chkGearBox.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkGearBox.Location = New System.Drawing.Point(52, 66)
        Me.chkGearBox.Name = "chkGearBox"
        Me.chkGearBox.Size = New System.Drawing.Size(82, 21)
        Me.chkGearBox.TabIndex = 1
        Me.chkGearBox.Text = "Gear Box"
        Me.chkGearBox.UseVisualStyleBackColor = True
        '
        'chkBumper
        '
        Me.chkBumper.AutoSize = True
        Me.chkBumper.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkBumper.Location = New System.Drawing.Point(52, 39)
        Me.chkBumper.Name = "chkBumper"
        Me.chkBumper.Size = New System.Drawing.Size(75, 21)
        Me.chkBumper.TabIndex = 0
        Me.chkBumper.Text = "Bumper"
        Me.chkBumper.UseVisualStyleBackColor = True
        '
        'cboCarType
        '
        Me.cboCarType.FormattingEnabled = True
        Me.cboCarType.Location = New System.Drawing.Point(320, 135)
        Me.cboCarType.Name = "cboCarType"
        Me.cboCarType.Size = New System.Drawing.Size(141, 21)
        Me.cboCarType.TabIndex = 25
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(228, 136)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(68, 20)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "Car Type"
        '
        'txtCustomerName
        '
        Me.txtCustomerName.Location = New System.Drawing.Point(321, 95)
        Me.txtCustomerName.Name = "txtCustomerName"
        Me.txtCustomerName.Size = New System.Drawing.Size(141, 20)
        Me.txtCustomerName.TabIndex = 37
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(196, 95)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(119, 20)
        Me.Label1.TabIndex = 36
        Me.Label1.Text = "Customer Name"
        '
        'Home
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Cornsilk
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.txtCustomerName)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.txtWelcome)
        Me.Controls.Add(Me.btnLogout)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.txtPrice)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtAddress)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cboCarType)
        Me.Controls.Add(Me.Label2)
        Me.Name = "Home"
        Me.Text = "Home"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents txtWelcome As TextBox
    Friend WithEvents btnLogout As Button
    Friend WithEvents btnCalc As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents radDelivery As RadioButton
    Friend WithEvents radCollection As RadioButton
    Friend WithEvents txtPrice As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtAddress As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents chkSparkPlugs As CheckBox
    Friend WithEvents chkMirrors As CheckBox
    Friend WithEvents chkOilfilters As CheckBox
    Friend WithEvents chkTires As CheckBox
    Friend WithEvents chkWindsheilds As CheckBox
    Friend WithEvents chkBreak As CheckBox
    Friend WithEvents chkBattery As CheckBox
    Friend WithEvents chkRims As CheckBox
    Friend WithEvents chkGearBox As CheckBox
    Friend WithEvents chkBumper As CheckBox
    Friend WithEvents cboCarType As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtCustomerName As TextBox
    Friend WithEvents Label1 As Label
End Class
