﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Data.OleDb

Public Class Home
    ' Define the Order class outside of the Home class for better accessibility
    Public Class Order
        Public Property CustomerName As String
        Public Property Address As String
        Public Property Items As List(Of OrderItem)

        Public Sub New(name As String)
            CustomerName = name
            Items = New List(Of OrderItem)()
        End Sub

        Public ReadOnly Property TotalPrice As Decimal
            Get
                Return Items.Sum(Function(item) item.Price)
            End Get
        End Property
    End Class

    Public Class OrderItem
        Public Property ItemName As String
        Public Property Price As Decimal

        Public Sub New(name As String, price As Decimal)
            ItemName = name
            Me.Price = price ' Use Me to refer to the property
        End Sub
    End Class

    Private Sub SaveOrderToDatabase(order As Order, carType As String)
        Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Student\Documents\Sikhumba1.mdb"
        Dim query As String = "INSERT INTO Orders ([CustomerName], [CarType], [Address], [ChosenItems], [TotalPrice]) VALUES (@CustomerName, @CarType, @Address, @ChosenItems, @TotalPrice)"

        Using connection As New OleDbConnection(connectionString)
            Using command As New OleDbCommand(query, connection)
                command.Parameters.AddWithValue("@CustomerName", order.CustomerName)
                command.Parameters.AddWithValue("@CarType", carType)
                command.Parameters.AddWithValue("@Address", order.Address)
                ' Join all chosen item names into a single string
                command.Parameters.AddWithValue("@ChosenItems", String.Join(", ", order.Items.Select(Function(item) item.ItemName)))
                command.Parameters.AddWithValue("@TotalPrice", order.TotalPrice)

                Try
                    connection.Open()
                    command.ExecuteNonQuery()
                Catch ex As Exception
                    MessageBox.Show("Error saving order: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End Using
        End Using
    End Sub

    Public loggedInUserName As String

    Private Sub Home_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtWelcome.Text = "Welcome, " & loggedInUserName
        txtWelcome.ReadOnly = True

        cboCarType.Items.Add("SUV")
        cboCarType.Items.Add("Sedan")
        cboCarType.Items.Add("HatchBack")
        cboCarType.Items.Add("Coupe")
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim address As String = txtAddress.Text
        Dim price As Double = 0
        Dim extra As Double
        Dim totalPrice As Double
        Dim itemCount As Integer = 0 ' Initialize item count

        ' Calculate prices based on selected options
        If chkBumper.Checked Then
            price += 2000
            itemCount += 1
        End If
        If chkGearBox.Checked Then
            price += 1500
            itemCount += 1
        End If
        If chkRims.Checked Then
            price += 3000
            itemCount += 1
        End If
        If chkBattery.Checked Then
            price += 3500
            itemCount += 1
        End If
        If chkMirrors.Checked Then
            price += 650
            itemCount += 1
        End If
        If chkBreak.Checked Then
            price += 800
            itemCount += 1
        End If
        If chkWindsheilds.Checked Then
            price += 2300
            itemCount += 1
        End If
        If chkTires.Checked Then
            price += 2500
            itemCount += 1
        End If
        If chkOilfilters.Checked Then
            price += 350
            itemCount += 1
        End If
        If chkSparkPlugs.Checked Then
            price += 900
            itemCount += 1
        End If

        ' Determine extra cost based on delivery method
        extra = If(radCollection.Checked, 0, 200)
        totalPrice = price + extra

        ' Apply discount if item count is 4 or more
        If itemCount >= 4 Then
            totalPrice *= 0.8 ' Apply 20% discount
        End If

        txtPrice.Text = FormatCurrency(totalPrice)
        txtPrice.ReadOnly = True

        ' Create an order
        Dim order As New Order(loggedInUserName)
        order.Address = address

        ' Add chosen items to the order
        If chkBumper.Checked Then order.Items.Add(New OrderItem("Bumper", 2000))
        If chkGearBox.Checked Then order.Items.Add(New OrderItem("GearBox", 1500))
        If chkRims.Checked Then order.Items.Add(New OrderItem("Rims", 3000))
        If chkBattery.Checked Then order.Items.Add(New OrderItem("Battery", 3500))
        If chkMirrors.Checked Then order.Items.Add(New OrderItem("Mirrors", 650))
        If chkBreak.Checked Then order.Items.Add(New OrderItem("Break", 800))
        If chkWindsheilds.Checked Then order.Items.Add(New OrderItem("Windsheilds", 2300))
        If chkTires.Checked Then order.Items.Add(New OrderItem("Tires", 2500))
        If chkOilfilters.Checked Then order.Items.Add(New OrderItem("Oil Filters", 350))
        If chkSparkPlugs.Checked Then order.Items.Add(New OrderItem("Spark Plugs", 900))

        ' Save the order to the database
        SaveOrderToDatabase(order, cboCarType.SelectedItem.ToString())

        ' Optionally show a message to the user
        MessageBox.Show("Order calculated and saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class
