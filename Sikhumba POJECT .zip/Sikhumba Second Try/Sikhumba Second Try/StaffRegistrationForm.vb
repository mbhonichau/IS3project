﻿Imports System.Data.OleDb
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports System.IO

Public Class StaffRegistrationForm

    ' This property will hold the generated StaffID
    Public Property StaffID As String

    Private Sub StaffRegistrationForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Optional: Set default values or focus on the first input field
        cboGender.Items.Add("Male")
        cboGender.Items.Add("Female")
        cboGender.Items.Add("Other")

        txtName.Focus()
    End Sub

    Private Sub btnGenerateID_Click(sender As Object, e As EventArgs) Handles btnGenerateID.Click
        ' Get the first name, last name, and ID number from the user input
        Dim firstName As String = txtName.Text.Trim()
        Dim lastName As String = txtSurname.Text.Trim()
        Dim idNumber As String = txtIdNumber.Text.Trim()

        ' Ensure that the necessary fields are not empty
        If firstName = "" Or lastName = "" Or idNumber = "" Then
            MessageBox.Show("Please fill out all fields before generating the StaffID.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Generate a StaffID by combining the first two letters of the first and last name with the ID number
        StaffID = firstName.Substring(0, 2).ToUpper() & lastName.Substring(0, 2).ToUpper() & "_" & idNumber

        ' Display the generated StaffID in the text box
        txtStaffID.Text = StaffID
        txtStaffID.ReadOnly = True

        ' Optional: Display a message indicating success
        MessageBox.Show("StaffID generated successfully: " & StaffID, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        ' Check if StaffID is generated before submitting
        If txtStaffID.Text = "" Then
            MessageBox.Show("Please generate a StaffID before submitting.", "Missing StaffID", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Save the data to the database
        SaveToDatabase()

        ' Save the data to a PDF
        SaveToPdf(txtName.Text, txtSurname.Text, txtIdNumber.Text, StaffID)

        ' Notify the user
        MessageBox.Show("Staff registration completed and saved!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

        ' Close the form after registration is done
        Me.Hide()
        StaffLogin.Show()
    End Sub

    ' Method to save registration data to a database
    Private Sub SaveToDatabase()
        Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Student\Documents\Sikhumba1.mdb"

        Using connection As New OleDbConnection(connectionString)
            connection.Open()

            ' Ensure the parameter names match and use correct data types
            Dim query As String = "INSERT INTO Staff ( [StaffID], [Name], [Surname], [IdNumber], [Age], [Cellphone], [Gender], [Email], [Password]) VALUES (@StaffID,  @Name, @Surname, @IDNumber, @Age, @Cellphone, @Gender, @Email, @Password)"

            Using command As New OleDbCommand(query, connection)
                ' Add parameters
                command.Parameters.AddWithValue("@StaffID", txtStaffID.Text.Trim())
                command.Parameters.AddWithValue("@Name", txtName.Text.Trim())
                command.Parameters.AddWithValue("@Surname", txtSurname.Text.Trim())
                command.Parameters.AddWithValue("@IDNumber", txtIdNumber.Text.Trim()) ' Ensure this matches your table's type
                command.Parameters.AddWithValue("@Age", Convert.ToInt32(txtAge.Text.Trim())) ' Convert to Integer
                command.Parameters.AddWithValue("@Cellphone", txtCellphone.Text.Trim()) ' Ensure this matches your table's type
                command.Parameters.AddWithValue("@Gender", cboGender.SelectedItem.ToString())
                command.Parameters.AddWithValue("@Email", txtEmail.Text.Trim())
                command.Parameters.AddWithValue("@Password", txtPassword.Text.Trim())


                Try
                    command.ExecuteNonQuery()
                Catch ex As OleDbException
                    MessageBox.Show("Database error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End Using
        End Using
    End Sub




    ' Method to save registration data to a PDF
    Private Sub SaveToPdf(Name As String, Surname As String, idNumber As String, staffID As String)
        Dim document As New Document()

        ' Specify the path where the PDF will be saved
        Dim pdfPath As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), staffID & "_StaffDetails.pdf")

        ' Create the PDF file
        PdfWriter.GetInstance(document, New FileStream(pdfPath, FileMode.Create))

        ' Open the document to add content
        document.Open()

        ' Add content to the PDF
        document.Add(New Paragraph("Staff Registration Details"))
        document.Add(New Paragraph("Name: " & Name))
        document.Add(New Paragraph("Surname: " & Surname))
        document.Add(New Paragraph("ID Number: " & idNumber))
        document.Add(New Paragraph("StaffID: " & staffID))

        ' Close the document
        document.Close()

        ' Notify user where the PDF is saved
        MessageBox.Show("PDF saved successfully at: " & pdfPath, "PDF Generated", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

End Class

