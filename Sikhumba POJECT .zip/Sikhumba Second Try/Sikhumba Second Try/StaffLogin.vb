﻿Imports System.Data.OleDb

Public Class StaffLogin

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim staffId As String = txtStaffID.Text.Trim()
        Dim password As String = txtPassword.Text.Trim()

        Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Student\Documents\Sikhumba1.mdb"
        Dim query As String = "SELECT COUNT(*) FROM Staff WHERE StaffID = @StaffID AND Password = @Password"

        Using connection As New OleDbConnection(connectionString)
            Using command As New OleDbCommand(query, connection)
                command.Parameters.AddWithValue("@StaffID", staffId)
                command.Parameters.AddWithValue("@Password", password)

                Try
                    connection.Open()
                    Dim count As Integer = Convert.ToInt32(command.ExecuteScalar())

                    If count > 0 Then
                        MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                        ' Hide the login form
                        Me.Hide()

                        ' Create an instance of the StaffOrders form
                        Dim staffOrders As New StaffOrders(staffId) ' Pass the staff ID

                        staffOrders.Show() ' Show the StaffOrders form
                        ' Show the StaffOrders form

                    Else
                        MessageBox.Show("Invalid Staff ID or Password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    End If
                Catch ex As Exception
                    MessageBox.Show("An error occurred: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End Using
        End Using
    End Sub

    Private Sub StaffLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Initialization code if needed
    End Sub

    Private Sub txtCreateAcc_Click(sender As Object, e As EventArgs) Handles txtCreateAcc.Click
        Me.Hide()
        StaffRegistrationForm.Show()
    End Sub

    Private Sub btnForgotPassword_Click(sender As Object, e As EventArgs) Handles btnForgotPassword.Click
        Me.Hide()
        PasswordReset.Show()
    End Sub
End Class
