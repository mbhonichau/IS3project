﻿Public Class StaffBetween
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnRegisterStaff.Click
        Me.Hide()
        StaffRegistrationForm.Show()
    End Sub

    Private Sub btnLoginStaff_Click(sender As Object, e As EventArgs) Handles btnLoginStaff.Click
        Me.Hide()
        StaffLogin.Show()
    End Sub
End Class