﻿Imports System.Data.OleDb
Imports System.Security.Cryptography

Public Class Form1
    ' Database connection string
    Dim conString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Student\Documents\Sikhumba1.mdb"
    Dim con As New OleDbConnection(conString)
    Dim cmd As OleDbCommand

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        ' Check if email is empty
        If IsEmpty(txtEmail.Text) = True Then
            MsgBox("Email cannot be empty")
            txtEmail.Focus()
            Exit Sub
        End If

        ' Check if password is empty
        If IsEmpty(txtPassword.Text) = True Then
            MsgBox("Password cannot be empty")
            txtPassword.Focus()
            Exit Sub
        End If

        Try
            con.Open()
            ' Using parameterized query to prevent SQL injection
            Dim stmt As String = "SELECT * FROM Customers WHERE Email = ? AND Password = ?"
            cmd = New OleDbCommand(stmt, con)

            ' Add email and password parameters
            cmd.Parameters.AddWithValue("?", txtEmail.Text)
            cmd.Parameters.AddWithValue("?", txtPassword.Text)

            Dim reader As OleDbDataReader = cmd.ExecuteReader()

            If reader.Read() Then
                ' Retrieve user's full name from the database
                Dim fullName As String = reader("Name").ToString()

                ' Show success message
                MessageBox.Show("Login successful")

                ' Hide the login form and show the Home form, passing the full name
                Me.Hide()
                Dim homeForm As New Home
                homeForm.loggedInUserName = fullName ' Pass full name to the Home form
                homeForm.Show()
            Else
                MessageBox.Show("Invalid Login, Please Check!")
                txtEmail.Clear()
                txtPassword.Clear()
            End If
        Catch ex As Exception
            MsgBox("Database Error: " & ex.Message)
        Finally
            ' Ensure the connection is closed
            If con IsNot Nothing Then con.Close()
        End Try
    End Sub

    ' Function to check if a text box is empty
    Private Function IsEmpty(textbox As String) As Boolean
        Dim results As Boolean
        If textbox.Trim = "" Then
            results = True
        Else
            results = False
        End If
        Return results
    End Function

    ' Handles Register button click
    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtEmail.Clear()
        txtPassword.Clear()
    End Sub

    ' Handles the form load event
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Any initialization logic here
    End Sub

    ' Handles form closing event
    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Dim var = MsgBox("Are you sure you want to close the app?", vbYesNo + vbQuestion, "Close App?")
        If var = vbYes Then
            Me.Dispose()
        Else
            e.Cancel = True
        End If
    End Sub

    ' Handles Forgot Password button click
    Private Sub btnResetPassword_Click(sender As Object, e As EventArgs) Handles btnForgotPassword.Click
        Me.Hide()
        PasswordResetCustomers.Show()
    End Sub

    ' Handles "Show Password" checkbox change


    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Hide()
        registration.Show()
    End Sub

    Private Sub btnStaff_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub btnStaffOnly_Click(sender As Object, e As EventArgs) Handles btnStaffOnly.Click
        Me.Hide()
        StaffBetween.Show()
    End Sub
End Class


