﻿Imports System.Data.OleDb ' Use OleDb for Access Database

Public Class PasswordResetCustomers

    ' Event for the button click
    Private Sub btnResetPassword_Click(sender As Object, e As EventArgs) Handles btnResetPassword.Click
        Dim email As String = txtemail.Text
        Dim newPassword As String = txtNewPassword.Text
        Dim confirmNewPassword As String = txtConfirmNewPassword.Text

        ' Validate inputs
        If String.IsNullOrEmpty(email) Or String.IsNullOrEmpty(newPassword) Or String.IsNullOrEmpty(confirmNewPassword) Then
            MessageBox.Show("Please fill in all fields.")
            Return
        End If

        ' Check if the new password and confirm password match
        If newPassword <> confirmNewPassword Then
            MessageBox.Show("Passwords do not match. Please enter the same password.")
            Return
        End If

        ' Call the function to reset the password
        If ResetUserPassword(email, newPassword) Then
            MessageBox.Show("Password has been reset successfully!")

            ' Close the current form and open the login form
            Dim loginForm As New Form1()
            loginForm.Show()
            Me.Close() ' Close the PasswordResetCustomers form
        Else
            MessageBox.Show("Error: Invalid email or password could not be reset.")
        End If
    End Sub

    ' Function to reset the password in the database
    Public Function ResetUserPassword(email As String, newPassword As String) As Boolean
        Dim success As Boolean = False

        Try
            ' Connection string to your database
            Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Student\Documents\Sikhumba1.mdb")
                ' Open connection
                con.Open()

                ' Query to update the password for the specified email
                Dim query As String = "UPDATE Customers SET [Password] = @NewPassword WHERE [Email] = @Email"

                Using cmd As New OleDbCommand(query, con)
                    ' Add parameters to prevent SQL Injection
                    cmd.Parameters.AddWithValue("@NewPassword", newPassword) ' The new password
                    cmd.Parameters.AddWithValue("@Email", email) ' The email to identify the user

                    ' Execute the query
                    Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                    ' If the query affected rows, the password was updated
                    If rowsAffected > 0 Then
                        success = True
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message)
        End Try

        Return success
    End Function

    Private Sub PasswordReset_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Optional: Load any necessary data on form load
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        Form1.Show()
    End Sub
End Class
