﻿Imports System.Data.OleDb

Public Class StaffOrders

    Private staffId As String

    ' Constructor to accept the staff ID
    Public Sub New(staffId As String)
        InitializeComponent() ' Initialize components (auto-generated)
        Me.staffId = staffId
    End Sub

    Private order As Home.Order ' Reference to the Order object

    ' Constructor to receive the order
    Public Sub New(order As Home.Order)
        InitializeComponent()
        Me.order = order
        LoadOrderDetails() ' Call to load order details
    End Sub

    Private Sub LoadOrderDetails()
        ' Clear the list box first
        lstOrderDetaills.Items.Clear()

        ' Add customer name and address (if desired)
        lstOrderDetaills.Items.Add($"Customer Name: {order.CustomerName}")
        lstOrderDetaills.Items.Add($"Address: {order.Address}")

        ' Add each item in the order
        For Each item In order.Items
            lstOrderDetaills.Items.Add($"{item.ItemName} - R{item.Price:F2}")
        Next

        ' Display total price

    End Sub

    Private Sub StaffOrders_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Optionally load orders on form load or leave it empty
    End Sub

    Private Sub btnShowOrders_Click(sender As Object, e As EventArgs) Handles btnShowOrders.Click
        LoadOrdersFromDatabase()
    End Sub

    Private Sub LoadOrdersFromDatabase()
        Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Student\Documents\Sikhumba1.mdb"
        Dim query As String = "SELECT CustomerName, CarType, Address, ChosenItems, TotalPrice FROM Orders"

        Using connection As New OleDbConnection(connectionString)
            Using command As New OleDbCommand(query, connection)
                Try
                    connection.Open()
                    Using reader As OleDbDataReader = command.ExecuteReader()
                        ' Clear the list box first
                        lstOrderDetaills.Items.Clear()

                        ' Read each order and display in the list box
                        While reader.Read()
                            lstOrderDetaills.Items.Add($"Customer Name: {reader("CustomerName")}")
                            lstOrderDetaills.Items.Add($"Car Type: {reader("CarType")}")
                            lstOrderDetaills.Items.Add($"Address: {reader("Address")}")
                            lstOrderDetaills.Items.Add($"Chosen Items: {reader("ChosenItems")}")
                            lstOrderDetaills.Items.Add($"Total Price: R{Convert.ToDecimal(reader("TotalPrice")):F2}")
                            lstOrderDetaills.Items.Add(New String("-"c, 30)) ' Separator for clarity
                        End While
                    End Using
                Catch ex As Exception
                    MessageBox.Show("Error loading orders: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End Using
        End Using
    End Sub

    Private Sub btnSaveInfo_Click(sender As Object, e As EventArgs) Handles btnSaveInfo.Click
        Me.Hide()
        StaffLogin.Show()
    End Sub
End Class
